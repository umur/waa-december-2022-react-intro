import React from 'react';

class Home extends React.Component {
  render() {
    return (
      <main>
        <div class="container">
          <h2>Products</h2>
          <div id="content"></div>
        </div>
      </main>
    );
  }
}

export default Home;
